const Registration = require('./app/src/Methods')
const registration = new Registration()
// registration.registerUser()
// registration.sendDataInterval()

registration.drain()