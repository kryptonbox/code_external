const Web3 = require('web3')

class Provider {
  constructor() {
    //setup web3 provider
    // this.web3 = new Web3(
    //   let web3 = new Web3(Web3.givenProvider || "ws://localhost:8545");
    //   new Web3.providers.HttpProvider('http://localhost:8545'),
    // )
    this.web3 = new Web3(Web3.givenProvider || "http://localhost:8545");
  }
}

module.exports = Provider
